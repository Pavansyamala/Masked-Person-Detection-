# Mask detection > 2024-01-24 7:27pm
https://universe.roboflow.com/mask-detection-tzsop/mask-detection-nh1j7

Provided by a Roboflow user
License: CC BY 4.0

